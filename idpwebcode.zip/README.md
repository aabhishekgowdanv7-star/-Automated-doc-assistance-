# Institution Document Box

Simple Express app where students can apply for documents and the institution stores them in one of two physical "boxes" (`box1`, `box2`). Faculty can upload documents to the assigned box and set an availability date.

Quick start

1. Install dependencies:

```
npm install
```

2. Start the server:

```
npm start
```

3. Open in your browser: http://localhost:3000

Usage

- Student: fill the form on the home page to apply. You will receive the assigned box name and box password (the password equals the box name: `box1` or `box2`).
- Faculty/Admin: open the admin page at http://localhost:3000/admin to see requests and upload completed documents to the assigned box. Set the availability date when uploading.
- Box access: students can open `/box/box1` or `/box/box2` and enter the box password (`box1` or `box2`) to see available documents and download them.

Files created

- [server.js](server.js) - main server
- [views/index.ejs](views/index.ejs) - student form
- [views/applied.ejs](views/applied.ejs) - confirmation
- [views/admin.ejs](views/admin.ejs) - faculty dashboard
- [views/box.ejs](views/box.ejs) - box access
- [data/requests.json](data/requests.json) - stored requests

const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, 'data');
const BOXES_DIR = path.join(__dirname, 'boxes');
const REQUESTS_FILE = path.join(DATA_DIR, 'requests.json');
const COUNTER_FILE = path.join(DATA_DIR, 'counter.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

// In-memory session store (rgNo -> session data)
const sessions = {};

function ensureDirs(){
  if(!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, {recursive:true});
  if(!fs.existsSync(BOXES_DIR)) fs.mkdirSync(BOXES_DIR, {recursive:true});
  const b1 = path.join(BOXES_DIR, 'box1');
  const b2 = path.join(BOXES_DIR, 'box2');
  if(!fs.existsSync(b1)) fs.mkdirSync(b1, {recursive:true});
  if(!fs.existsSync(b2)) fs.mkdirSync(b2, {recursive:true});
  const tmpDir = path.join(__dirname, 'tmp');
  if(!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, {recursive:true});
  if(!fs.existsSync(REQUESTS_FILE)) fs.writeFileSync(REQUESTS_FILE, JSON.stringify([]));
  if(!fs.existsSync(COUNTER_FILE)) fs.writeFileSync(COUNTER_FILE, JSON.stringify({last:0}));
}

ensureDirs();

app.set('view engine', 'ejs');
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/boxes', express.static(BOXES_DIR));

const upload = multer({ dest: path.join(__dirname, 'tmp') });

function loadRequests(){
  try{
    return JSON.parse(fs.readFileSync(REQUESTS_FILE, 'utf8'));
  }catch(e){
    return [];
  }
}

function saveRequests(reqs){
  fs.writeFileSync(REQUESTS_FILE, JSON.stringify(reqs, null, 2));
}

function getNextBox(){
  const c = JSON.parse(fs.readFileSync(COUNTER_FILE, 'utf8'));
  c.last = (c.last % 2) + 1;
  fs.writeFileSync(COUNTER_FILE, JSON.stringify(c));
  return c.last === 1 ? 'box1' : 'box2';
}

function loadUsers(){
  try{
    return JSON.parse(fs.readFileSync(USERS_FILE, 'utf8'));
  }catch(e){
    return [];
  }
}

// Predefined credentials
const PREDEF_RG = '4mc25ri003';
const PREDEF_PW = '27-7-2007';

// Middleware to check if student is logged in
function isStudentLoggedIn(req, res, next){
  const rgNo = req.query.rgNo || (req.session && req.session.rgNo);
  if(rgNo && sessions[rgNo]){
    req.student = sessions[rgNo];
    next();
  } else {
    res.redirect('/student-login');
  }
}

app.get('/student-login', (req, res) => {
  res.render('student-login', { error: null });
});

app.post('/student-login', (req, res) => {
  const { rgNo, password } = req.body;
  const users = loadUsers();
  const user = users.find(u => u.usn === rgNo && u.password === password);
  
  if(!user && (rgNo !== PREDEF_RG || password !== PREDEF_PW)){
    return res.render('student-login', { error: 'Invalid USN or password' });
  }
  // Create session
  sessions[rgNo] = { rgNo, loginTime: new Date() };
  res.redirect(`/student-dashboard?rgNo=${rgNo}`);
});

app.get('/student-logout', (req, res) => {
  const rgNo = req.query.rgNo;
  if(rgNo) delete sessions[rgNo];
  res.redirect('/');
});

app.get('/student-dashboard', isStudentLoggedIn, (req, res) => {
  const documentTypes = ['Transcript','Degree Certificate','Migration Certificate','Other'];
  const requests = loadRequests();
  const myRequests = requests.filter(r => r.rgNo === req.student.rgNo);
  res.render('student-dashboard', { student: req.student, documentTypes, myRequests });
});

app.get('/', (req, res) => {
  res.render('home');
});

app.post('/student/apply', isStudentLoggedIn, (req, res) => {
  const { name, documentType } = req.body;
  const rgNo = req.student.rgNo;
  if(!name || !documentType) return res.status(400).send('Missing fields');
  
  const requests = loadRequests();
  const assignedBox = getNextBox();
  const request = {
    id: Date.now().toString(),
    rgNo,
    name,
    documentType,
    assignedBox,
    status: 'pending',
    availabilityDate: null
  };
  requests.push(request);
  saveRequests(requests);
  res.render('applied', { request, boxPassword: assignedBox });
});

app.get('/admin-login', (req, res) => {
  res.render('admin-login', { error: null });
});

app.post('/admin-login', (req, res) => {
  const { loginId, password } = req.body;
  const ADMIN_ID = 'admin';
  const ADMIN_PW = 'admin002';
  if(loginId !== ADMIN_ID || password !== ADMIN_PW){
    return res.render('admin-login', { error: 'Invalid login ID or password' });
  }
  res.redirect('/admin');
});

app.get('/admin', (req, res) => {
  const requests = loadRequests();
  res.render('admin', { requests });
});

app.post('/admin/mark-ready', (req, res) => {
  const { requestId, availabilityDate } = req.body;
  if(!requestId || !availabilityDate) return res.status(400).send('Missing requestId or availabilityDate');
  const requests = loadRequests();
  const r = requests.find(x=>x.id===requestId);
  if(!r) return res.status(404).send('Request not found');
  r.status = 'available';
  r.availabilityDate = availabilityDate;
  saveRequests(requests);
  res.redirect('/admin');
});

app.post('/admin/delete-request', (req, res) => {
  const { requestId } = req.body;
  if(!requestId) return res.status(400).send('Missing requestId');
  let requests = loadRequests();
  const index = requests.findIndex(x=>x.id===requestId);
  if(index === -1) return res.status(404).send('Request not found');
  requests.splice(index, 1);
  saveRequests(requests);
  res.redirect('/admin');
});

app.get('/student-status', (req, res) => {
  const rgNo = req.query.rgNo ? req.query.rgNo.trim() : '';
  let statusResults = null;
  if(rgNo){
    const requests = loadRequests();
    statusResults = requests.filter(r => r.rgNo === rgNo);
  }
  res.render('student-status', { rgNo, statusResults });
});

app.get('/box/:boxName', (req, res) => {
  res.render('box', { boxName: req.params.boxName, error: null, files: null });
});

app.post('/box/:boxName', (req, res) => {
  const boxName = req.params.boxName;
  const { password } = req.body;
  if(password !== boxName){
    return res.render('box', { boxName, error: 'Invalid password', files: null });
  }
  const requests = loadRequests();
  const files = requests.filter(r=>r.assignedBox===boxName && r.status==='available');
  res.render('box', { boxName, error: null, files });
});

app.listen(PORT, ()=>{
  console.log(`Server running on http://localhost:${PORT}`);
});
